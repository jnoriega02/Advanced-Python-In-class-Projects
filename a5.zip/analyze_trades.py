#ANNALUZE_TRADES FILES 
#JUVINY NORIEGA
#Z1917876
#ASSIGNMENT 5
import sys
from senate_stock_trades import ticker,util,compare

_usage_='''
Usage:
  analyze_trades.py ticker
  analyze_trades.py compare <senator1> <senator2>
'''


#printing usage statement
def print_usage():
    print (_usage_)

#main driver code 
def main():
    if len(sys.argv)< 2:
        print_usage()
        sys.exit(1)
        
    subcommand = sys.argv[1]
    
    if subcommand=='ticker':
        total_trades=ticker.count_trades(sys.argv[2])
        total_amount=ticker.sum_trades(util.senate_stock_data,sys.argv[2])
        
        print ("Number of Trades:")
        print(f'{total_trades}')
        print ("Sum of Trades:")
        print(total_amount)
        
    elif subcommand=='compare':
        if len(sys.argv)!= 4: #usage error displayed
            print("Usage: analyze_trades.py compare <senator1> <senator2>")
            sys.exit(1)
        senator1,senator2 = sys.argv[2],sys.argv[3]
        
        trade_count_diff = compare.count_diff(senator1, senator2)
        trade_amount_diff = compare.amount_diff(senator1, senator2)
        
        print (senator1, 'has',trade_count_diff,"trades with value",trade_amount_diff,'than',senator2)
        
    else:
        print("Invalid subcommand. Please use 'Ticker' or 'Compare'")
        print_usage()
        sys.exit(1)
        
    
        
        
if __name__=='__main__':
    main()
    
    
        
        

        
        
