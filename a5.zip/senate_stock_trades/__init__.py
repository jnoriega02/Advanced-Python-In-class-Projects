 #python module for analyzing trade statisitics
 
 
 
#three modules (util.py, ticker.py, and compare.py)