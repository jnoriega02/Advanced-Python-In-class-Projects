#module with three emethods names get_dtaa_add_amount_ranges and sub_amount_ranges
import os,json

senate_stock_data=None

#read and parse the senate-stock-trades.json datafile and store it in a module variable
def get_data():
    global senate_stock_data
    if senate_stock_data is None:
         
      fname = os.path.join(os.path.dirname(__file__),'senate-stock-trades.json')
      try:
           with open(fname,'r') as file:
                senate_stock_data = json.load(file)
      except FileNotFoundError: #checking if file exist
            raise FileNotFoundError("file not found")
      except Exception as error:
           print("Error loading data:",error)
           senate_stock_data=[]
    return senate_stock_data


def add_amount_ranges(range_1: int ,range_2: int):
     total=tuple(map(sum,zip(range_1,range_2)))
     
     return total
     
def sub_amount_ranges(range_1: int ,range_2: int):
     total=tuple(map(sum,zip(range_1,range_2)))
     return total
     






