# module that has two mehttods that both take one paramter , the ticker symbol

from . import util
import collections

senate_data=util.get_data()   #obtain data

#should return a dictionary of the form {<senator>: <count>} with the counts of trades for each senator
def count_trades(ticker):    
    global senate_data
    senator_names=[transaction['senator'] for transaction in senate_data if transaction['ticker']==ticker] #make a list with all senator names even duplicates

    collection_senate_data=collections.Counter(senator_names) #count each senator name
    
    my_dict=dict(collection_senate_data) 
    return my_dict

# should return a dictionary of the form {<senator>: (<min_value>,<max_value)} with 
# the range of possible trade values. Use the 
# util.add_amount_ranges method from Part 1a to add the amount ranges.
def sum_trades(data : dict,ticker: chr):
    sen_poss_values={}
    for transaction in data:
        # current_senator=transaction_list['senator']
        # senator_list=[x['range'] for x in data if x['senator']==current_senator]

        if transaction['ticker']==ticker:
            sen_poss_values[transaction['senator']]=util.add_amount_ranges(sen_poss_values.get(transaction['senator'],(0,0)),transaction['amount_range'])
    return sen_poss_values

    

    
    