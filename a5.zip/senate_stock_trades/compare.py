#module that calculates comparative information between two senators

from . import util,ticker
import collections


# Given two senators’ names as parameters, 
# the count_diff method should return the difference
# between the number of transactions between the two senators
def count_diff(senator_one,senator_two):
    
    senator_names=[transaction['senator'] for transaction in util.senate_stock_data]
    collection_senate_data=collections.Counter(senator_names) #count each senator name
    
    data=dict(collection_senate_data) 
    
    difference= data.get(senator_one)-data.get(senator_two)
    return difference
#the amount_diff method should return the ranged difference between
# the amounts of all trades. This difference should be 
# computed by using the util.sub_amount_ranges method
def amount_diff(senator1, senator2):
    data=util.senate_stock_data

    #filtering by date
    # if start_date or end_date:
    #     data=data_filter(data,start_date,end_date)
    sen2_count=(0,0)
    sen1_count=(0,0)
    for item in data:
        if senator1==item['senator']:
            sen1_count=util.add_amount_ranges(sen1_count,item['amount_range'])
            
        elif senator2==item['senator']:
            sen2_count=util.add_amount_ranges(sen2_count,item['amount_range'])
    
    # Calculate the ranged difference between the amounts
    
    return util.sub_amount_ranges(sen1_count, sen2_count)
